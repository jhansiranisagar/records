import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        Person person = new Person("Alice", "Smith", 20);
        System.out.println("Is adult: " + person.isAdult());

        Point3D a = new Point3D(0, 0, 0);
        Point3D b = new Point3D(3, 4, 0);
        System.out.println("Distance: " + Point3D.distance(a, b));

        List<Order> orders = List.of(
                new Order("Laptop", 2, 500.0),
                new Order("Mouse", 3, 20.0),
                new Order("Laptop", 1, 500.0)
        );

        OrderProcessor processor = new OrderProcessor();
        Map<String, Double> summary = processor.summarize(orders);

        System.out.println("Order summary:");
        summary.forEach((item, total) ->
                System.out.println(item + ": " + total));
    }
}
