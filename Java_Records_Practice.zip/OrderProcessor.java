import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class OrderProcessor {
    public Map<String, Double> summarize(List<Order> orders) {
        return orders.stream()
                .collect(Collectors.groupingBy(
                        Order::item,
                        Collectors.summingDouble(Order::total)
                ));
    }
}
