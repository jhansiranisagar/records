public record Person(String firstName, String lastName, int age) {
    public boolean isAdult() {
        return age >= 18;
    }
}
