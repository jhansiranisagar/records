public record Order(String item, int quantity, double price) {
    public double total() {
        return quantity * price;
    }
}
